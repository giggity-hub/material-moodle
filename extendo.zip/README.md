# material-moodle
### What you need
+ Node/npm


### building the Extension
install all the packages with
```npm install```
and then build the Extension with
```npm run build```
